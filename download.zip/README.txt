PROYECTO FINAL - ANALITICA DE DATOS
Estudiante: Diego Velez Cogollo - Universidad Cooperativa de Colombia

Tema: prediccion de dengue complicado en ninos con regresion logistica y red neuronal.
Datos: MASTER_CHART_F1000Research.xlsx (303 ninos; estudio F1000Research 2022).

Contenido del ZIP:
- index.html             Pagina web (abrir este archivo). Incluye los 2 modelos incrustados.
- modelos.json           Parametros exportados: escalador, regresion logistica y red neuronal.
- dengue_original.csv    Datos originales (columnas renombradas).
- dengue_limpio.csv      Datos despues de la limpieza y variables nuevas.
- Proyecto_Final.ipynb   Notebook de Google Colab (agregar manualmente).
- Sustentacion.docx      Documento de explicacion (agregar manualmente).

La pagina calcula las predicciones con JavaScript usando los parametros de modelos.json.
Para publicar: subir index.html a la carpeta htdocs del hosting.
Proyecto academico: no es una herramienta de diagnostico medico.
